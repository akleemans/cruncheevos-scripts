#!/usr/bin/env node
/*
 * Recomputes `overall` in the games table, in place, from whatever the score columns say
 * right now. Run it whenever a score changes - including one you typed into the spreadsheet
 * yourself. No API requests, nothing else is touched.
 *
 * This is deliberately separate from build-table.js. That one rebuilds the whole table from
 * the pipeline (shortlist, research.json, request pages, code notes); this one only reads
 * the CSV and writes the CSV, so a hand-edited size_score or genre_score takes effect
 * without going near research.json.
 *
 * A row with anything in excluded_as scores 0 rather than being removed - a 50+ code note
 * count or a ruled-out genre sinks to the bottom of the same table instead of vanishing.
 *
 * Rows are re-sorted best first, and needs_research is refreshed from size_score.
 *
 * Usage: node next-game/update-scores.js ps1
 *        node next-game/update-scores.js ps1 --dry-run  - report changes, write nothing
 */

import {existsSync, readdirSync} from 'node:fs';
import {join} from 'node:path';
import {CONSOLE_ALIASES} from './consoles.js';
import {readCsv, writeCsv} from './csv.js';
import {slugify} from './ra-api.js';
import {byOverall, overallScore} from './scoring.js';

const DEFAULT_OUT = 'next-game/data';

const parseArgs = (argv) => {
  const options = {out: DEFAULT_OUT, dryRun: false};
  const consoles = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--dry-run') options.dryRun = true;
    else if (arg === '--out') options.out = argv[++i];
    else if (arg.startsWith('--')) throw new Error(`Unknown option: ${arg}`);
    else consoles.push(arg);
  }

  if (consoles.length !== 1) {
    throw new Error('Name exactly one console, e.g. `node next-game/update-scores.js ps1`');
  }

  options.console = consoles[0];
  return options;
};

const findTable = (input, dir) => {
  const wanted = slugify(CONSOLE_ALIASES[input.toLowerCase()] ?? input);
  const slugs = readdirSync(dir)
    .filter((file) => file.startsWith('games-') && file.endsWith('.csv'))
    .map((file) => file.slice('games-'.length, -'.csv'.length));

  const match = slugs.find((slug) => slug === wanted) ?? slugs.find((slug) => slug.includes(wanted));
  if (!match) {
    throw new Error(`No games table for "${input}" in ${dir}. Have: ${slugs.join(', ') || 'none'}\n`
      + 'Run build-table.js first.');
  }

  const file = join(dir, `games-${match}.csv`);
  if (!existsSync(file)) throw new Error(`No ${file}.`);
  return file;
};

const main = () => {
  const options = parseArgs(process.argv.slice(2));
  const file = findTable(options.console, options.out);
  const {columns, rows} = readCsv(file);

  if (!columns.includes('overall')) throw new Error(`${file} has no overall column.`);

  let changed = 0;
  const examples = [];

  for (const row of rows) {
    const before = row.overall;
    const after = overallScore(row);
    row.overall = after ?? '';
    if (columns.includes('needs_research')) {
      row.needs_research = String(row.size_score ?? '').trim() === '' ? 'yes' : '';
    }

    if (String(before) !== String(row.overall)) {
      changed += 1;
      if (examples.length < 8) examples.push(`${row.title}: ${before || '-'} -> ${row.overall || '-'}`);
    }
  }

  rows.sort(byOverall);

  console.log(`${file}: ${rows.length} rows, ${changed} with a changed overall.`);
  for (const example of examples) console.log(`  ${example}`);
  if (changed > examples.length) console.log(`  ... and ${changed - examples.length} more`);

  if (options.dryRun) {
    console.log('\nDry run, nothing written.');
    return;
  }

  writeCsv(file, columns, rows);
  console.log(`\nWrote ${file}`);
};

try {
  main();
} catch (error) {
  console.error(error.message);
  process.exit(1);
}
