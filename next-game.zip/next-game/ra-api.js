/*
 * Shared RetroAchievements Web API plumbing for the next-game scripts.
 *
 * Everything goes through one queue that keeps at least RATE_LIMIT_MS between requests,
 * so two callers in the same process can never double the request rate.
 *
 * This talks to the documented V1 API (https://api-docs.retroachievements.org/), which
 * authenticates with the web API key as the `y` query parameter. The unannounced V2 API
 * lives at https://api.retroachievements.org/v2 and takes the same key as an X-API-Key
 * header instead - see the notes in fetch-game-lists.js.
 */

import 'dotenv/config';
import {existsSync, readFileSync, writeFileSync} from 'node:fs';

export const API = 'https://retroachievements.org/API';
export const RATE_LIMIT_MS = 1100;

export const slugify = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export const readJson = (file) => JSON.parse(readFileSync(file, 'utf8'));

export const writeJson = (file, data) => writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* Serialises every API call and keeps at least RATE_LIMIT_MS between them. */
let nextRequestAt = 0;
const queue = async (fn) => {
  const wait = nextRequestAt - Date.now();
  if (wait > 0) await sleep(wait);
  nextRequestAt = Date.now() + RATE_LIMIT_MS;
  return fn();
};

const apiKey = () => {
  const key = process.env.RA_API_KEY;
  if (!key) {
    console.error('Missing RA_API_KEY - add it to .env (https://retroachievements.org/settings).');
    process.exit(1);
  }
  return key;
};

/* Every V1 endpoint answers with either an array or an object, so callers say which they expect. */
export const get = (endpoint, params, {expect = 'array'} = {}) => queue(async () => {
  const url = new URL(`${API}/${endpoint}`);
  url.search = new URLSearchParams({...params, y: apiKey()}).toString();

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`${endpoint} responded ${response.status} ${response.statusText}`);
  }

  const body = await response.json();
  if (expect === 'array' && !Array.isArray(body)) {
    throw new Error(`${endpoint} returned an unexpected body: ${JSON.stringify(body).slice(0, 200)}`);
  }
  return body;
});

/* Fetches once and caches the raw response; later runs read the file back. */
export const cached = async (file, fetcher, {refresh, quiet = false} = {}) => {
  if (!refresh && existsSync(file)) {
    if (!quiet) console.log(`  cached  ${file}`);
    return readJson(file);
  }

  const data = await fetcher();
  writeJson(file, data);
  if (!quiet) console.log(`  saved   ${file}${Array.isArray(data) ? ` (${data.length} entries)` : ''}`);
  return data;
};
