#!/usr/bin/env node
/*
 * Fetches RetroAchievements game lists per console and reports the games that are
 * still up for grabs: no achievements yet, and no active set claim on them.
 *
 * Three API endpoints are involved (see https://api-docs.retroachievements.org/):
 *   API_GetConsoleIDs.php   - to resolve console names like "gba" into console IDs
 *   API_GetActiveClaims.php - every in-progress set claim, so claimed games drop out
 *   API_GetGameList.php     - the full game list per console, paginated
 *
 * Covers these requirements.md rules on its own:
 *   Console       - one list per console, see DEFAULT_CONSOLES / CONSOLE_ALIASES
 *   Type          - RA tags non-retail entries in the title, EXCLUDED_TAGS drops them
 *   No achievements yet, not claimed yet
 *   No Japanese game - only as a hint: releases tagged (Japan) and nothing else are
 *                      flagged japanOnly, since a JP-only release is not quite the
 *                      same thing as a Japanese game. Not filtered out.
 *
 * Not covered here, because GetGameList does not carry the data:
 *   Genre         - enrich-candidates.js is stage 2 and fetches it per game
 *   Player requests - no endpoint exposes a per-game count, in V1 or in the unannounced
 *                     V2 API. API_GetUserSetRequests.php is per user only, and the V2
 *                     user-game-list-entries resource is scoped to one user as well.
 *                     The game page shows it, but Cloudflare blocks scripted fetches.
 *   Code notes    - not in the Web API either. The connect API has it, same one that
 *                   @cruncheevos/cli uses: POST dorequest.php with r=codenotes2&g=<id>,
 *                   authenticated with the Username/Token out of RAPrefs*.cfg in RACACHE.
 *
 * Requests are spaced at least RATE_LIMIT_MS apart and every raw response is cached
 * in the output folder, so re-runs (and tweaking the filters) cost zero requests
 * unless --refresh is passed. A full run over DEFAULT_CONSOLES is roughly 50-70
 * requests, over half of them PlayStation pages.
 *
 * Needs RA_API_KEY in .env - get one at https://retroachievements.org/settings
 *
 * Usage: node next-game/fetch-game-lists.js             - every console in DEFAULT_CONSOLES
 *        node next-game/fetch-game-lists.js gba n64     - just those, by alias, name or ID
 *        node next-game/fetch-game-lists.js --refresh   - ignore the cache, re-fetch
 *        node next-game/fetch-game-lists.js --all       - keep hacks/homebrew/protos/subsets
 *        node next-game/fetch-game-lists.js --out <dir> - write somewhere else
 *
 * Writes into next-game/data: consoles.json, claims.json and gamelist-<console>.json are
 * the raw cache, candidates-<console>.json the filtered results that stage 2 reads.
 */

import {mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {CONSOLE_ALIASES, DEFAULT_CONSOLES} from './consoles.js';
import {cached, get, slugify, writeJson} from './ra-api.js';

const PAGE_SIZE = 500;
const CLAIM_LIMIT = 1000; // API_GetActiveClaims.php returns at most this many

const DEFAULT_OUT = 'next-game/data';

/* RA marks non-retail entries with ~tags~ in the title and subsets with a [Subset - x] suffix. */
const TITLE_TAG = /~([^~]+)~/g;
const SUBSET = /\[Subset\s*-\s*[^\]]*\]/i;
const PARENTHESISED = /\(([^)]+)\)/g;
const KNOWN_REGIONS = ['USA', 'Europe', 'Japan', 'World', 'Australia', 'Korea', 'Brazil'];
const EXCLUDED_TAGS = ['hack', 'homebrew', 'prototype', 'demo', 'test kit', 'subset', 'z'];

const fetchConsoles = () => get('API_GetConsoleIDs.php', {a: 1, g: 1});

const fetchClaims = async () => {
  const claims = await get('API_GetActiveClaims.php', {});
  if (claims.length >= CLAIM_LIMIT) {
    console.warn(`  warning: got ${claims.length} claims, the API caps at ${CLAIM_LIMIT} - some may be missing`);
  }
  return claims;
};

/* GetGameList can return thousands of rows per console, so walk it in pages. */
const fetchGames = async (consoleId) => {
  const games = [];

  for (let offset = 0; ; offset += PAGE_SIZE) {
    const page = await get('API_GetGameList.php', {i: consoleId, f: 0, h: 0, c: PAGE_SIZE, o: offset});
    games.push(...page);
    console.log(`    offset ${offset}: ${page.length} games (${games.length} total)`);
    if (page.length < PAGE_SIZE) return games;
  }
};

const describe = (title) => {
  const tags = [...title.matchAll(TITLE_TAG)].map((match) => match[1].trim().toLowerCase());
  if (SUBSET.test(title)) tags.push('subset');

  const bare = title.replace(TITLE_TAG, '').replace(SUBSET, '').trim();
  const regions = [...bare.matchAll(PARENTHESISED)]
    .flatMap((match) => match[1].split(','))
    .map((region) => region.trim())
    .filter((region) => KNOWN_REGIONS.includes(region));

  return {
    tags,
    regions,
    bare,
    japanOnly: regions.length > 0 && regions.every((region) => region === 'Japan'),
  };
};

const toCandidate = (game) => {
  const {tags, regions, bare, japanOnly} = describe(game.Title);

  return {
    id: game.ID,
    title: game.Title,
    sortTitle: bare,
    consoleId: game.ConsoleID,
    consoleName: game.ConsoleName,
    numLeaderboards: game.NumLeaderboards,
    dateModified: game.DateModified,
    tags,
    regions,
    japanOnly,
    url: `https://retroachievements.org/game/${game.ID}`,
  };
};

/*
 * A candidate is a game with no achievements and no active claim. Hacks, homebrew,
 * prototypes, demos and subsets are dropped unless --all is passed (requirements.md
 * asks for retail games); Japan-only releases are kept, but flagged.
 */
const pickCandidates = (games, claimed, {all}) => games
  .filter((game) => Number(game.NumAchievements) === 0)
  .filter((game) => !claimed.has(Number(game.ID)))
  .map(toCandidate)
  .filter((game) => all || !game.tags.some((tag) => EXCLUDED_TAGS.includes(tag)))
  .sort((a, b) => a.sortTitle.localeCompare(b.sortTitle));

const parseArgs = (argv) => {
  const options = {refresh: false, all: false, out: DEFAULT_OUT};
  const consoles = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--refresh') options.refresh = true;
    else if (arg === '--all') options.all = true;
    else if (arg === '--out') options.out = argv[++i];
    else if (arg.startsWith('--')) throw new Error(`Unknown option: ${arg}`);
    else consoles.push(arg);
  }

  options.consoles = consoles.length > 0 ? consoles : DEFAULT_CONSOLES;
  return options;
};

const resolveConsole = (input, consoles) => {
  const wanted = (CONSOLE_ALIASES[input.toLowerCase()] ?? input).toLowerCase();
  const match = consoles.find((entry) => String(entry.ID) === input || entry.Name.toLowerCase() === wanted);

  if (!match) {
    const known = consoles.map((entry) => entry.Name).sort().join(', ');
    throw new Error(`Unknown console "${input}". Known consoles: ${known}`);
  }
  return match;
};

const main = async () => {
  const options = parseArgs(process.argv.slice(2));
  mkdirSync(options.out, {recursive: true});

  console.log('Consoles:');
  const consoles = await cached(join(options.out, 'consoles.json'), fetchConsoles, options);
  const targets = options.consoles.map((input) => resolveConsole(input, consoles));

  console.log('Active claims:');
  const claims = await cached(join(options.out, 'claims.json'), fetchClaims, options);
  const claimed = new Set(claims.map((claim) => Number(claim.GameID)));

  const results = [];

  for (const target of targets) {
    const slug = slugify(target.Name);
    console.log(`${target.Name} (ID ${target.ID}):`);

    const games = await cached(join(options.out, `gamelist-${slug}.json`), () => fetchGames(target.ID), options);
    const candidates = pickCandidates(games, claimed, options);

    writeJson(join(options.out, `candidates-${slug}.json`), candidates);
    console.log(`  ${candidates.length} unclaimed games without achievements (of ${games.length})`);
    results.push({name: target.Name, total: games.length, candidates});
  }

  const total = results.reduce((sum, result) => sum + result.candidates.length, 0);
  console.log(`\n${total} candidates in total - next: enrich-candidates.js, then build-table.js`);
};

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
