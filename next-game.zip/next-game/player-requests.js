/*
 * Reads the set-request counts that were copied out of the RetroAchievements
 * "Most Requested Sets" pages into next-game/player-requests*.txt.
 *
 * No API exposes a per-game request count - V1 and V2 both only answer per user - and the
 * game page is behind Cloudflare, so this is a manual copy-paste of the web UI. Each page
 * holds 200 rows; pages 1-3 run from 339 requests down to 3, so any PlayStation game that
 * does not appear in them has 3 requests or fewer. Add a player-requests4.txt and it gets
 * picked up automatically.
 *
 * The copied text has one record per game, laid out as:
 *
 *   Guardian's Crusade     <- full title, the only line we keep
 *   Guardian's Crusade     <- repeated, or split into parts for [Subset - x] entries
 *   PS1
 *   PS1
 *   Sep 23, 1998           <- may be just a year, so it can look like a count
 *   (blank)
 *   252                    <- request count
 *   -No                    <- "Yes" when the set is already claimed
 *
 * Records are found by the PS1/PS1 pair and closed by the Yes/-No marker rather than by
 * counting lines, because subset rows have extra title lines and the date field varies.
 */

import {globSync, readFileSync} from 'node:fs';

const REQUEST_FILES = 'next-game/player-requests*.txt';

/* Anything not listed sits at or below the smallest count the copied pages reached. */
export const UNLISTED_MAX = 3;

/*
 * Titles have to be matched by name, since the page carries no game IDs. Strips accents,
 * RA's ~tags~ and [Subset - x] suffixes, and every run of punctuation, so "Linda³ Again"
 * and "Shaolin | Lord of Fist" line up with the API's spelling.
 */
export const normaliseTitle = (title) => title
  .normalize('NFD')
  .replace(/[̀-ͯ]/g, '')
  .toLowerCase()
  .replace(/\[subset[^\]]*\]/g, '')
  .replace(/~[^~]*~/g, '')
  .replace(/[^a-z0-9]+/g, ' ')
  .trim();

const parseFile = (file) => {
  const lines = readFileSync(file, 'utf8').split(/\r?\n/).map((line) => line.trim());
  const records = [];
  let start = 0;

  for (let i = 0; i < lines.length; i += 1) {
    if (!(lines[i] === 'PS1' && lines[i + 1] === 'PS1')) continue;

    /* The Yes/-No marker closes the record; without one this is not a row we understand. */
    let end = -1;
    for (let j = i + 2; j < lines.length && j < i + 12; j += 1) {
      if (lines[j] === 'Yes' || lines[j] === '-No') {
        end = j;
        break;
      }
    }
    if (end < 0) continue;

    /* The count is the last bare number before the marker - scanning forwards would hit the date. */
    let count = null;
    for (let k = end - 1; k > i + 1; k -= 1) {
      if (/^\d+$/.test(lines[k])) {
        count = Number(lines[k]);
        break;
      }
    }

    if (count !== null && lines[start]) {
      records.push({title: lines[start], count, claimed: lines[end] === 'Yes'});
    }
    start = end + 1;
    i = end;
  }

  return records;
};

/* Normalised title -> request count. Highest count wins if a title somehow repeats. */
export const loadRequestCounts = () => {
  const files = globSync(REQUEST_FILES).sort();
  const counts = new Map;

  for (const file of files) {
    for (const record of parseFile(file)) {
      const key = normaliseTitle(record.title);
      if (!counts.has(key) || counts.get(key) < record.count) counts.set(key, record.count);
    }
  }

  return {counts, files: files.length};
};
