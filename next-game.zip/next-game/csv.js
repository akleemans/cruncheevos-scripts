/*
 * Minimal CSV read/write for the games table.
 *
 * The table is round-tripped, not just written: build-table.js reads back the columns you
 * filled in by hand, and update-scores.js rewrites the file in place. So parsing has to
 * handle whatever a spreadsheet produces on save - quoted fields, commas and newlines
 * inside them, doubled quotes - rather than assuming the shape this project writes.
 */

import {readFileSync, writeFileSync} from 'node:fs';

const BOM = '﻿';

/* Splits one record into cells. Handles "" as an escaped quote inside a quoted field. */
const splitRow = (row) => {
  const cells = [];
  let cell = '';
  let quoted = false;

  for (let i = 0; i < row.length; i += 1) {
    const char = row[i];

    if (quoted) {
      if (char !== '"') cell += char;
      else if (row[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else quoted = false;
      continue;
    }

    if (char === '"') quoted = true;
    else if (char === ',') {
      cells.push(cell);
      cell = '';
    } else cell += char;
  }

  cells.push(cell);
  return cells;
};

/*
 * Splits the file into records. A newline inside a quoted field is part of the value, not
 * a record break, so this cannot just split on \n.
 */
const splitRecords = (text) => {
  const records = [];
  let record = '';
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];

    if (char === '"') quoted = !quoted;

    if (!quoted && (char === '\n' || char === '\r')) {
      if (record !== '') records.push(record);
      record = '';
      if (char === '\r' && text[i + 1] === '\n') i += 1;
      continue;
    }

    record += char;
  }

  if (record !== '') records.push(record);
  return records;
};

/* Returns {columns, rows} with rows as plain objects keyed by column name. */
export const readCsv = (file) => {
  const text = readFileSync(file, 'utf8').replace(new RegExp(`^${BOM}`), '');
  const records = splitRecords(text);
  if (records.length === 0) return {columns: [], rows: []};

  const columns = splitRow(records[0]);
  const rows = records.slice(1).map((record) => {
    const cells = splitRow(record);
    return Object.fromEntries(columns.map((column, index) => [column, cells[index] ?? '']));
  });

  return {columns, rows};
};

const cell = (value) => {
  const text = value === null || value === undefined ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

/* BOM and CRLF so Excel opens it as UTF-8 without asking. */
export const writeCsv = (file, columns, rows) => {
  const lines = [columns.join(','), ...rows.map((row) => columns.map((column) => cell(row[column])).join(','))];
  writeFileSync(file, `${BOM}${lines.join('\r\n')}\r\n`);
};
