#!/usr/bin/env node
/*
 * Builds the one table this whole project exists to produce: every candidate game, one row
 * each, one column per thing we have learned about it. Nothing is split into a second file
 * and nothing is dropped - filter on excluded_as / needs_research in the spreadsheet.
 *
 * Columns fill in as the earlier stages run:
 *   fetch-game-lists.js   -> id, title, url
 *   enrich-candidates.js  -> genre, developer, publisher, released, demoted_achievements
 *   fetch-code-notes.js   -> code_notes, code_notes_score
 *   player-requests*.txt  -> player_requests, request_score
 *   research.json         -> size_score, ip_score, japan_only override, and genre/genre_score overrides
 *   title heuristic       -> japan_only guess when research.json has no override, see JAPAN_TITLE_MARKERS
 *
 * Scores are 1-10 for the requirements.md criteria that are a matter of degree rather than
 * yes/no, and `overall` is their weighted mean - see WEIGHTS. Two columns are for you:
 * want_to_play and my_notes. Two say what to do next: excluded_as says why a row is out of
 * the running - a genre family, 50+ code notes (a hard no as a junior dev), or Japan-only -
 * and needs_research marks rows still waiting on a size score.
 *
 * Local only, no API requests, instant. Re-run it after editing research.json or after any
 * other stage finishes.
 *
 * Usage: node next-game/build-table.js ps1
 *        node next-game/build-table.js ps1 --min 6   - write only rows scoring 6+
 */

import {existsSync, readdirSync} from 'node:fs';
import {join} from 'node:path';
import {CONSOLE_ALIASES} from './consoles.js';
import {readCsv, writeCsv} from './csv.js';
import {UNLISTED_MAX, loadRequestCounts, normaliseTitle} from './player-requests.js';
import {readJson, slugify} from './ra-api.js';
import {CARRIED_SCORES, MANUAL_COLUMNS, byOverall, overallScore} from './scoring.js';

const DEFAULT_OUT = 'next-game/data';
const RESEARCH_FILE = 'next-game/research.json';

/*
 * Scores are 1-10, higher is a better fit. Matching is case-insensitive substring against
 * the whole genre string, and the LOWEST matching score wins, so "Action, Platformer"
 * scores as a platformer rather than as an action game.
 *
 * The first block is straight out of requirements.md. The second is my own guess at how
 * much room a genre leaves for creative challenges - tune it freely, nothing depends on it.
 */
const GENRE_SCORES = [
  // requirements.md, Genre section
  {match: '2d platform', score: 1, why: 'no 2D platformer'},
  {match: 'platform', score: 2, unless: '3d', why: 'no 2D platformer'},
  {match: 'racing', score: 1, why: 'no racing'},
  {match: 'driving', score: 1, why: 'no racing'},
  {match: 'puzzle', score: 1, why: 'no puzzle games'},
  {match: 'visual novel', score: 1, why: 'no visual novels'},
  {match: 'horror', score: 2, why: 'no horror'},
  {match: 'dungeon crawler', score: 3, why: 'close to Monster Force'},
  {match: 'rpg', score: 5, why: 'RPG - only if not excessive'},
  {match: 'role-playing', score: 5, why: 'RPG - only if not excessive'},

  // not in requirements.md - how much substance the genre usually offers
  {match: 'mahjong', score: 1},
  {match: 'educational', score: 1},
  {match: 'quiz', score: 2},
  {match: 'pinball', score: 2},
  {match: 'rhythm', score: 2},
  {match: 'board', score: 2},
  {match: 'card', score: 2},
  {match: 'compilation', score: 2},
  {match: 'fishing', score: 2},
  {match: 'sports', score: 3},
  {match: 'fighting', score: 4},
  {match: 'life simulation', score: 4},
  {match: 'rail shooter', score: 5},
  {match: 'simulation', score: 5},
  {match: 'point-and-click', score: 6},
  {match: 'strategy', score: 6},
  {match: 'shoot', score: 6},
  {match: 'beat', score: 6},
  {match: 'tactical', score: 7},
  {match: 'real-time strategy', score: 7},
  {match: 'action', score: 8},
  {match: 'adventure', score: 8},
  {match: 'shooter', score: 8},
  {match: 'action-adventure', score: 9},
  {match: 'stealth', score: 9},
  {match: 'metroidvania', score: 9},
];

/*
 * Genres to drop from the sheet outright, rather than score low. The first group is
 * requirements.md; the rest are genres Adrianus is not interested in developing for.
 * Excluded rows are not thrown away - they stay in the table with excluded_as naming the
 * family that caught them, so a wrong call here is visible and one filter from reversible.
 *
 * Only games with a known genre can be excluded, which is 39% of the PlayStation list.
 * Matching is case-insensitive substring, so "Sports - Fishing" is caught by 'sports'.
 */
const EXCLUDED_GENRES = [
  // requirements.md, Genre section
  {family: 'racing', match: ['racing', 'driving', 'kart']},
  {family: 'puzzle', match: ['puzzle']},
  {family: 'visual novel', match: ['visual novel']},
  {family: '2D platformer', match: ['2d platform', '2.5d platform']},

  // not interested in developing for these
  {family: 'sports', match: ['sports', 'wrestling', 'billiards', 'fishing', 'golf', 'bowling', 'soccer', 'football']},
  {family: 'pinball/rhythm/board', match: ['pinball', 'rhythm', 'board game', 'card', 'mahjong', 'casino']},
  {family: 'educational/compilation', match: ['educational', 'quiz', 'game show', 'compilation', 'minigames']},
  {family: 'life/management sim', match: ['life simulation', 'management simulation', 'dating simulation']},
  {family: 'fighting', match: ['fighting']},
  {family: 'tactical/turn-based RPG', match: ['tactical rpg', 'turn-based rpg', 'tactical role-playing', 'turn-based role-playing']},
];

/*
 * Code notes, scored on a slope rather than a cutoff. Notes already written mean somebody
 * has mapped part of the memory: a handful is nothing, but a game that is largely mapped
 * has both less work left to enjoy and a decent chance somebody is circling it.
 * requirements.md calls under 20 fine, so that is full marks, falling to nothing at 50.
 */
const CODE_NOTES_BEST = 20;
const CODE_NOTES_WORST = 50;

const scoreCodeNotes = (count) => {
  if (count <= CODE_NOTES_BEST) return 10;
  if (count >= CODE_NOTES_WORST) return 0;
  const span = CODE_NOTES_WORST - CODE_NOTES_BEST;
  return Math.round(((CODE_NOTES_WORST - count) / span) * 10 * 10) / 10;
};

const excludedGenre = (genre) => {
  const text = (genre ?? '').trim().toLowerCase();
  if (!text) return null;
  return EXCLUDED_GENRES.find((rule) => rule.match.some((needle) => text.includes(needle)))?.family ?? null;
};

/*
 * Why a row is out of the running, or null while it is still in play. Heavily mapped games
 * are a hard no as a junior dev, and (per an explicit decision after japan_only had real
 * data behind it, superseding the earlier "ignore for now") a Japan-only release is a hard
 * no too - both are excluded outright rather than merely scored down, since a low score on
 * one component of a weighted mean still leaves a row mid-table.
 */
const exclusionReason = (genre, noteCount, japanOnly) => {
  if (typeof noteCount === 'number' && noteCount >= CODE_NOTES_WORST) return `${noteCount} code notes`;
  if (japanOnly) return 'Japan-only';
  return excludedGenre(genre);
};

/*
 * Set requests, scored as a sweet spot rather than "more is better". A game nobody has
 * asked for has no audience waiting; a heavily requested one is likely to be claimed by
 * somebody else first, which matters because the next claim is months away. Bands are
 * inclusive upper bounds - tune freely.
 */
const REQUEST_SCORES = [
  {max: UNLISTED_MAX, score: 3, why: 'barely requested - no audience waiting'},
  {max: 9, score: 6},
  {max: 50, score: 10},
  {max: 80, score: 8},
  {max: 120, score: 6},
  {max: 200, score: 4, why: 'heavily requested - could be claimed first'},
  {max: Infinity, score: 2, why: 'heavily requested - could be claimed first'},
];

const scoreRequests = (count) => {
  const band = REQUEST_SCORES.find((rule) => count <= rule.max);
  return {score: band.score, why: band.why ? [band.why] : []};
};

const COLUMNS = [
  'overall', 'excluded_as', 'needs_research',
  'id', 'title', 'genre', 'genre_source', 'developer', 'publisher', 'released',
  'genre_score', 'size_score', 'request_score', 'code_notes_score', 'ip_score',
  'player_requests', 'code_notes', 'demoted_achievements', 'japan_only', 'japan_source',
  'want_to_play', 'my_notes', 'auto_notes',
  'url',
];

/*
 * Guesses whether a title never left Japan. RA stores every title in Latin script even for
 * Japan-only games, so there is no character set to detect - this instead looks for
 * romanized Japanese grammar (particles, common story-title words) that essentially never
 * appears in a title that went through Western localization. It is tuned for precision, not
 * recall: confirmed against the actual PS1 candidate list, it flags 88 titles with no
 * observed false positive, but it misses plenty of Japan-only games with plainer titles
 * (e.g. "Alive", "Deep Freeze") that research.json's `japan` field catches instead when
 * a game has actually been looked into. Absence of the flag means "no strong signal either
 * way", not "confirmed international release".
 */
const JAPAN_TITLE_MARKERS = new RegExp(
  '\\b(wo|ga|kara|made|dake|tte|gaiden|densetsu|monogatari|senki|taisen|kessen|bouken|'
  + 'daibouken|tantei|kyuujitsu|shoujo|shounen|oukoku|teikoku|ojousama|jiken|ibun|roku|'
  + 'tachi|kun|chan|sama|kyoku|jutsu|ryuu|hen|kaiten)\\b',
  'i',
);

const guessJapanOnly = (title, override) => {
  if (typeof override === 'boolean') return {likely: override, source: 'research'};
  if (JAPAN_TITLE_MARKERS.test(title)) return {likely: true, source: 'guess'};
  return {likely: false, source: ''};
};

/*
 * A missing genre scores a neutral 5 rather than nothing. Now that `overall` blends several
 * signals, leaving it out would let a game with no genre be ranked on its request count
 * alone, which floats unknowns to the top of the sheet. genre_source stays empty and the
 * note says why, so a placeholder 5 is never mistaken for a real reading.
 */
const scoreGenre = (genre) => {
  const text = (genre ?? '').trim().toLowerCase();
  if (!text) return {score: 5, why: ['no genre on RA - neutral placeholder'], known: false};

  const hits = GENRE_SCORES.filter((rule) => text.includes(rule.match) && !(rule.unless && text.includes(rule.unless)));
  if (hits.length === 0) return {score: 5, why: ['genre not in the scoring table'], known: true};

  const lowest = Math.min(...hits.map((rule) => rule.score));
  const why = hits.filter((rule) => rule.score === lowest && rule.why).map((rule) => rule.why);
  return {score: lowest, why, known: true};
};

const buildRow = (game, research, requestCounts, codeNotes) => {
  const notes = research[String(game.id)] ?? {};
  const genre = notes.genre || game.genre || '';
  const genreSource = notes.genre ? 'research' : (game.genre ? 'ra' : '');
  const computed = scoreGenre(genre);
  /* A hand-set genre_score overrides the rules outright, for the cases where a rule is
   * right in general but wrong for this game - a horror game in a franchise worth doing. */
  const override = typeof notes.genre_score === 'number';
  const genreScore = override ? notes.genre_score : computed.score;
  const genreKnown = override || computed.known;
  const why = override ? ['genre score set by hand'] : computed.why;

  const size = typeof notes.size === 'number' ? notes.size : null;
  const ip = typeof notes.ip === 'number' ? notes.ip : null;

  /* Absent from the copied pages means at or below their smallest count, not zero. */
  const listed = requestCounts.get(normaliseTitle(game.title));
  const requests = listed ?? UNLISTED_MAX;
  const {score: requestScore, why: requestWhy} = scoreRequests(requests);

  /* Undefined means not checked yet, which is not the same as a game with zero notes. */
  const noteCount = codeNotes[String(game.id)];
  const notesKnown = typeof noteCount === 'number';

  const notesScore = notesKnown ? scoreCodeNotes(noteCount) : null;

  const {likely: japanOnly, source: japanSource} = guessJapanOnly(game.title, notes.japan);

  const autoNotes = [...why, ...requestWhy, ...(game.reasons ?? [])];
  if (notesKnown && noteCount > CODE_NOTES_BEST) {
    autoNotes.push(`${noteCount} code notes already written`);
  }
  if (game.unofficialAchievements > 0) autoNotes.push(`${game.unofficialAchievements} demoted achievements exist`);
  if (notes.note) autoNotes.push(notes.note);

  const row = {
    excluded_as: exclusionReason(genre, notesKnown ? noteCount : null, japanOnly) ?? '',
    id: game.id,
    title: game.title,
    genre,
    genre_source: genreSource,
    developer: game.developer ?? '',
    publisher: game.publisher ?? '',
    released: game.released ?? '',
    player_requests: listed ?? `<=${UNLISTED_MAX}`,
    genre_score: genreScore,
    size_score: size,
    request_score: requestScore,
    ip_score: ip,

    genre_known: genreKnown,
    auto_notes: [...new Set(autoNotes)].join('; '),
    code_notes: notesKnown ? noteCount : '',
    code_notes_score: notesScore ?? '',
    demoted_achievements: game.unofficialAchievements || '',
    japan_only: japanOnly ? 'yes' : '',
    japan_source: japanSource,
    needs_research: typeof size === 'number' ? '' : 'yes',
    url: game.url,
  };

  return {...row, overall: overallScore(row)};
};

/* Written by fetch-code-notes.js; absent until that has run, which is fine. */
const loadCodeNotes = (dir) => {
  const file = join(dir, 'code-note-counts.json');
  return existsSync(file) ? readJson(file) : {};
};

const loadResearch = () => {
  if (!existsSync(RESEARCH_FILE)) return {};
  return Object.fromEntries(Object.entries(readJson(RESEARCH_FILE)).filter(([key]) => !key.startsWith('_')));
};

const parseArgs = (argv) => {
  const options = {out: DEFAULT_OUT, min: null};
  const consoles = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--min') options.min = Number(argv[++i]);
    else if (arg === '--out') options.out = argv[++i];
    else if (arg.startsWith('--')) throw new Error(`Unknown option: ${arg}`);
    else consoles.push(arg);
  }

  if (consoles.length !== 1) {
    throw new Error('Name exactly one console, e.g. `node next-game/build-table.js ps1`');
  }

  options.console = consoles[0];
  return options;
};

const findShortlist = (input, dir) => {
  const wanted = slugify(CONSOLE_ALIASES[input.toLowerCase()] ?? input);
  const slugs = readdirSync(dir)
    .filter((file) => file.startsWith('shortlist-') && file.endsWith('.json'))
    .map((file) => file.slice('shortlist-'.length, -'.json'.length));

  const match = slugs.find((slug) => slug === wanted) ?? slugs.find((slug) => slug.includes(wanted));
  if (!match) {
    throw new Error(`No shortlist for "${input}" in ${dir}. Have: ${slugs.join(', ') || 'none'}
`
      + 'Run enrich-candidates.js first.');
  }
  return {slug: match, file: join(dir, `shortlist-${match}.json`)};
};

const main = () => {
  const options = parseArgs(process.argv.slice(2));
  const {slug, file} = findShortlist(options.console, options.out);

  const shortlist = readJson(file);
  const research = loadResearch();
  const {counts: requestCounts, files: requestFiles} = loadRequestCounts();
  const codeNotes = loadCodeNotes(options.out);
  const name = shortlist[0]?.consoleName ?? slug;

  const csv = join(options.out, `games-${slug}.csv`);

  /*
   * Anything a person typed into the spreadsheet has to be read back before the table is
   * regenerated - rebuilding from the pipeline alone would wipe it without a word. That is
   * the two manual columns plus size_score/ip_score, which have no source but a person.
   */
  const carried = [...MANUAL_COLUMNS, ...CARRIED_SCORES];
  const kept = new Map;
  if (existsSync(csv)) {
    for (const row of readCsv(csv).rows) {
      const values = Object.fromEntries(carried.map((column) => [column, row[column] ?? '']));
      if (Object.values(values).some((value) => value !== '')) kept.set(String(row.id), values);
    }
  }

  const rows = shortlist
    .map((game) => buildRow(game, research, requestCounts, codeNotes))
    .map((row) => {
      const previous = kept.get(String(row.id)) ?? {};
      const merged = {...row};

      for (const column of carried) {
        /* research.json wins where it has a value; otherwise keep what the sheet had. */
        const fromPipeline = merged[column];
        const known = fromPipeline !== null && fromPipeline !== undefined && fromPipeline !== '';
        merged[column] = known ? fromPipeline : (previous[column] ?? '');
      }

      merged.needs_research = String(merged.size_score ?? '').trim() === '' ? 'yes' : '';
      return {...merged, overall: overallScore(merged)};
    })
    .sort(byOverall);

  const table = options.min === null ? rows : rows.filter((row) => Number(row.overall || 0) >= options.min);

  writeCsv(csv, COLUMNS, table);

  const inPlay = table.filter((row) => !row.excluded_as);
  const researched = inPlay.filter((row) => String(row.size_score ?? '').trim() !== '').length;
  const withGenre = inPlay.filter((row) => row.genre).length;
  const listedRequests = inPlay.filter((row) => row.player_requests !== `<=${UNLISTED_MAX}`).length;
  const checked = inPlay.filter((row) => row.code_notes !== '');

  console.log(`${name}: ${table.length} rows written, ${inPlay.length} still in play.`);
  console.log(`  genre       ${withGenre} known, ${inPlay.length - withGenre} missing on RA`);
  console.log(`  requests    ${listedRequests} matched from ${requestFiles} copied page(s), `
    + `rest assumed <=${UNLISTED_MAX}`);

  /* 50+ is a disqualifier, so anything still in play is either clean or on the slope. */
  const clean = checked.filter((row) => row.code_notes <= CODE_NOTES_BEST).length;
  console.log(`  code notes  ${checked.length} checked and still in play`
    + (checked.length > 0 ? `, ${clean} under ${CODE_NOTES_BEST}, ${checked.length - clean} on the slope` : ''));
  console.log(`  research    ${researched} sized, ${inPlay.filter((row) => row.needs_research).length} still to do`);
  if (kept.size > 0) console.log(`  carried     ${kept.size} rows with hand-entered values kept from the previous table`);

  const excluded = rows.filter((row) => row.excluded_as);
  const byNotes = excluded.filter((row) => row.excluded_as.endsWith('code notes'));
  const byJapan = excluded.filter((row) => row.excluded_as === 'Japan-only');
  const byGenre = excluded.filter((row) => !row.excluded_as.endsWith('code notes') && row.excluded_as !== 'Japan-only');

  if (byGenre.length > 0) {
    const byFamily = byGenre.reduce((tally, row) => ({...tally, [row.excluded_as]: (tally[row.excluded_as] ?? 0) + 1}), {});
    const listed = Object.entries(byFamily).sort((a, b) => b[1] - a[1]).map(([family, n]) => `${family} ${n}`);
    console.log(`  scored 0    ${byGenre.length} by genre: ${listed.join(', ')}`);
  }
  if (byJapan.length > 0) {
    console.log(`  scored 0    ${byJapan.length} for being Japan-only`);
  }
  if (byNotes.length > 0) {
    console.log(`  scored 0    ${byNotes.length} for having ${CODE_NOTES_WORST}+ code notes`);
  }

  console.log(`
Wrote ${csv}`);
};

try {
  main();
} catch (error) {
  console.error(error.message);
  process.exit(1);
}
