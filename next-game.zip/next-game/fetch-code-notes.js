#!/usr/bin/env node
/*
 * Stage 2.5: counts the code notes already written for each candidate.
 *
 * Notes already written mean somebody has mapped part of the memory, which is both a sign
 * of prior interest and less of the work left to enjoy. build-table.js scores the count on
 * a slope: full marks up to 20 notes, nothing at 50. No Web API exposes code notes, in V1 or V2, so this uses the connect API:
 * the same endpoint @cruncheevos/cli uses, and the same one RAIntegration talks to.
 *
 *   POST https://retroachievements.org/dorequest.php
 *   r=codenotes2&g=<gameId>&u=<username>&t=<token>
 *   -> {"Success": true, "CodeNotes": [{"User": .., "Address": "0x..", "Note": ".."}]}
 *
 * Credentials are read from RAPrefs*.cfg in the RACACHE directory - the same file the CLI
 * reads, written by the emulator when you log in. No password is involved and the token
 * never leaves the request; nothing here logs or writes it.
 *
 * This is an undocumented, emulator-facing endpoint, so it is deliberately slower than the
 * Web API scripts (RATE_LIMIT_MS below) and defaults to the top of the score sheet rather
 * than the whole list. Notes are cached per game, so it resumes after a Ctrl+C.
 *
 * Usage: node next-game/fetch-code-notes.js ps1              - top 200 of the score sheet
 *        node next-game/fetch-code-notes.js ps1 --limit 500  - go deeper
 *        node next-game/fetch-code-notes.js ps1 --all        - every row, slow
 *        node next-game/fetch-code-notes.js ps1 --dry-run    - print the cost only
 *
 * Writes data/code-notes/<gameId>.json plus data/code-note-counts.json, which
 * build-table.js picks up to fill the code_notes column.
 */

import {existsSync, mkdirSync, readFileSync, readdirSync} from 'node:fs';
import {join} from 'node:path';
import 'dotenv/config';
import {CONSOLE_ALIASES} from './consoles.js';
import {readJson, slugify, writeJson} from './ra-api.js';

const CONNECT_URL = 'https://retroachievements.org/dorequest.php';
const RATE_LIMIT_MS = 1500;
const DEFAULT_OUT = 'next-game/data';
const DEFAULT_LIMIT = 200;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/*
 * Username and token live in RAPrefs*.cfg next to the emulator, pointed at by RACACHE.
 * Same lookup @cruncheevos/cli does, so if the CLI works this does too.
 */
const credentials = () => {
  const cache = process.env.RACACHE;
  if (!cache) throw new Error('RACACHE is not set in .env - it must point at the emulator directory.');

  const file = readdirSync(cache).find((entry) => /^raprefs.*\.cfg$/i.test(entry));
  if (!file) throw new Error(`No RAPrefs*.cfg in ${cache} - log in with the emulator once.`);

  const config = JSON.parse(readFileSync(join(cache, file), 'utf8'));
  if (!config.Username || !config.Token) {
    throw new Error(`${file} has no Username/Token - log in with the emulator once.`);
  }
  return {username: config.Username, token: config.Token};
};

const fetchNotes = async (gameId, {username, token}) => {
  const body = new URLSearchParams({r: 'codenotes2', g: String(gameId), u: username, t: token});
  const response = await fetch(CONNECT_URL, {
    method: 'POST',
    headers: {'User-Agent': 'cruncheevos-scripts', 'Content-Type': 'application/x-www-form-urlencoded'},
    body,
  });

  if (!response.ok) throw new Error(`dorequest responded ${response.status} ${response.statusText}`);

  const payload = await response.json();
  if (payload.Success === false) {
    throw new Error(`dorequest refused the request: ${payload.Error ?? 'no reason given'}`);
  }

  /* A game with no notes answers with an empty list rather than an error. */
  return Array.isArray(payload.CodeNotes) ? payload.CodeNotes : [];
};

/*
 * RA keeps deleted notes as empty strings rather than removing the row, so an honest count
 * has to ignore those - otherwise a game that was mapped and cleaned up looks busy.
 */
const countLive = (notes) => notes.filter((note) => (note.Note ?? '').trim() !== '').length;

const parseArgs = (argv) => {
  const options = {out: DEFAULT_OUT, limit: DEFAULT_LIMIT, all: false, dryRun: false};
  const consoles = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--all') options.all = true;
    else if (arg === '--dry-run') options.dryRun = true;
    else if (arg === '--limit') options.limit = Number(argv[++i]);
    else if (arg === '--out') options.out = argv[++i];
    else if (arg.startsWith('--')) throw new Error(`Unknown option: ${arg}`);
    else consoles.push(arg);
  }

  if (consoles.length !== 1) {
    throw new Error('Name exactly one console, e.g. `node next-game/fetch-code-notes.js ps1`');
  }
  if (!options.all && (!Number.isInteger(options.limit) || options.limit < 1)) {
    throw new Error(`--limit needs a positive whole number, got ${options.limit}`);
  }

  options.console = consoles[0];
  return options;
};

/*
 * Works off the score sheet rather than the raw candidate list, so the games checked first
 * are the ones currently ranked highest - and so anything already filtered out by genre
 * never costs a request.
 */
const readSheet = (input, dir) => {
  const wanted = slugify(CONSOLE_ALIASES[input.toLowerCase()] ?? input);
  const slugs = readdirSync(dir)
    .filter((file) => file.startsWith('shortlist-') && file.endsWith('.json'))
    .map((file) => file.slice('shortlist-'.length, -'.json'.length));

  const match = slugs.find((slug) => slug === wanted) ?? slugs.find((slug) => slug.includes(wanted));
  if (!match) throw new Error(`No shortlist for "${input}" in ${dir}. Run enrich-candidates.js first.`);

  const csv = join(dir, `games-${match}.csv`);
  if (!existsSync(csv)) throw new Error(`No ${csv}. Run build-table.js first.`);

  /*
   * Only id and excluded_as matter, and neither ever holds a quoted comma, so the columns
   * are located by header name rather than by position - the column order does change.
   * Rows the genre filter already ruled out never cost a request.
   */
  const lines = readFileSync(csv, 'utf8').replace(/^\uFEFF/, '').trim().split(/\r?\n/);
  const header = lines[0].split(',');
  const idAt = header.indexOf('id');
  const excludedAt = header.indexOf('excluded_as');
  if (idAt < 0) throw new Error(`${csv} has no id column.`);

  const ids = lines.slice(1)
    .map((line) => line.split(','))
    .filter((cells) => excludedAt < 0 || !cells[excludedAt])
    .map((cells) => Number(cells[idAt]))
    .filter(Boolean);

  return {slug: match, ids};
};

const main = async () => {
  const options = parseArgs(process.argv.slice(2));
  const {slug, ids} = readSheet(options.console, options.out);
  const wanted = options.all ? ids : ids.slice(0, options.limit);

  const notesDir = join(options.out, 'code-notes');
  mkdirSync(notesDir, {recursive: true});
  const cached = new Set(readdirSync(notesDir).map((entry) => entry.replace('.json', '')));
  const toFetch = wanted.filter((id) => !cached.has(String(id)));

  const seconds = Math.ceil((toFetch.length * RATE_LIMIT_MS) / 1000);
  const estimate = seconds > 90 ? `about ${Math.ceil(seconds / 60)} min` : `about ${seconds}s`;
  console.log(`${slug}: ${wanted.length} games from the top of the sheet, `
    + `${cached.size} already cached, ${toFetch.length} to fetch (${estimate}).`);

  if (options.dryRun) {
    console.log('Dry run, stopping here.');
    return;
  }

  const {username, token} = credentials();
  console.log(`Authenticated as ${username} from RAPrefs. Ctrl+C is safe - each game is cached.\n`);

  for (const [index, id] of toFetch.entries()) {
    const notes = await fetchNotes(id, {username, token});
    writeJson(join(notesDir, `${id}.json`), notes);

    const position = String(index + 1).padStart(String(toFetch.length).length);
    console.log(`  [${position}/${toFetch.length}] game ${id}: ${countLive(notes)} notes`);
    if (index < toFetch.length - 1) await sleep(RATE_LIMIT_MS);
  }

  /* One rollup file so build-table.js does not have to read a directory of tiny files. */
  const counts = {};
  for (const entry of readdirSync(notesDir)) {
    counts[entry.replace('.json', '')] = countLive(readJson(join(notesDir, entry)));
  }

  const rollup = join(options.out, 'code-note-counts.json');
  writeJson(rollup, counts);

  const busy = Object.values(counts).filter((n) => n >= 20).length;
  console.log(`\n${Object.keys(counts).length} games checked, ${busy} have 20 or more notes.`);
  console.log(`Wrote ${rollup} - re-run build-table.js to fold it in.`);
};

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
