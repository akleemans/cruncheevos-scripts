Next game
=========
Requirements for picking my next game.

## Console
- Console not too simple (8-bit/16-bit, e.g. GB, GBC, NES, SNES etc.) - should be 32-bit
- Console not too complex - no PSP / PS2 / GameCube etc.
- Candidates: GBA, Nintendo DS, PS1

## Genre
- No 2D platformer (already did two of those: Rugrats & Turok)
- Nothing too similar to Monster Force (Action/Dungeon Crawler?)
- No racing game (too simple/don't like)
- No puzzle games/visual novels (too simple)
- No horror (exceptions possible for a franchise I like, e.g. Men in Black)
- No Japanese game
- RPG: Only if not too excessive (some RPGs can be huge)

## Game content
- Should be big/complex enough - enough game content (or long enough) to explore to allow for creative challenges

## Type
- No homebrews / hacks / prototypes / demo ⇒ Retail games are best
- Original IPs are better than licensed games

## RetroAchievements
- Must not have achievements yet
- Must not have many Code notes - less than 20 is probably okay
- Must not be claimed yet (see game lists in this folder)
- Should not have 100 or more player request, else somebody else might claim before me
