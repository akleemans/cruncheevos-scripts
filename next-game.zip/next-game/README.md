Next game
=========

Two-stage search for an unclaimed game to develop, filtered against [requirements.md](requirements.md).

Needs `RA_API_KEY` in `.env` (from https://retroachievements.org/settings). Everything is
rate limited to 1 request/s and cached in `data/`, so re-runs are free.

## Stage 1 - candidate lists

Cheap and broad: one `GetGameList` per console plus one `GetActiveClaims` for everything.

```
# fetches 'gba', 'ds', 'ps1', 'n64', 'dreamcast', 'saturn' - about 50-70 requests
node next-game/fetch-game-lists.js

node next-game/fetch-game-lists.js ps1        # just one console
node next-game/fetch-game-lists.js --refresh  # ignore the cache
node next-game/fetch-game-lists.js --all      # keep hacks/homebrew/protos/subsets
```

Writes `data/candidates-<console>.json`, which stage 2 reads.

## Stage 2 - shortlist with genres

Expensive: one `GetGameExtended` per game, so the whole PS1 list is about 31 minutes. It
prints the plan, then runs. Ctrl+C is safe - each response is cached as it arrives, so the
next run resumes where you stopped.

```
node next-game/enrich-candidates.js ps1               # the whole candidate list
node next-game/enrich-candidates.js ps1 --dry-run     # just print what it would cost
node next-game/enrich-candidates.js ps1 --limit 300   # stop after 300 games
```

Writes `data/shortlist-<console>.json`, which stage 3 turns into the table.

## Stage 2.5 - code notes

requirements.md wants fewer than 20 code notes. No Web API exposes them, so this uses the
connect API (`dorequest.php`, `r=codenotes2`) - the same endpoint `@cruncheevos/cli` uses.

Credentials come from `RAPrefs*.cfg` in the `RACACHE` directory, written by the emulator
when you log in. **No password is involved**, and the token is never logged or written out.

```
node next-game/fetch-code-notes.js ps1              # top 200 of the score sheet
node next-game/fetch-code-notes.js ps1 --limit 500
node next-game/fetch-code-notes.js ps1 --all        # every row
node next-game/fetch-code-notes.js ps1 --dry-run
```

It reads the score sheet, so it checks the highest-ranked games first and never spends a
request on something the genre filter already dropped. Rate limited to one request per
1.5s - slower than the Web API scripts, because this endpoint is undocumented and meant
for emulators. Each game is cached, so Ctrl+C is safe.

Writes `data/code-note-counts.json`; re-run stage 3 to fold it into the `code_notes` and
`code_notes_score` columns. Between 20 and 50 notes the score slides from 10 down to 0;
at 50 or more the game is excluded outright. Notes that RA has blanked out rather than deleted are not
counted, so a game that was mapped and then cleaned up does not look busy.

## Stage 3 - the games table

Local only, no requests, instant. Produces the one artefact everything else feeds:
`data/games-<console>.csv`.

```
node next-game/build-table.js ps1
node next-game/build-table.js ps1 --min 6   # write only rows scoring 6+
```

**Every candidate is in it, one row each** - nothing is split out and nothing is dropped.
Sorted by `overall` descending. Filter it in the spreadsheet:

| Column | Filled by | Meaning |
| --- | --- | --- |
| `overall` | computed | weighted mean of the known scores (size .35, genre .25, requests .15, notes .15, ip .1) - sort on this |
| `excluded_as` | stage 3 | empty = still in play; otherwise why it is disqualified - a genre family, or `<n> code notes` for 50+. Anything here forces `overall` to 0 |
| `needs_research` | stage 3 | `yes` = still waiting on a size score |
| `genre`, `developer`, `publisher`, `released` | stage 2 | |
| `genre_score` | stage 3 | from `GENRE_SCORES`, or set by hand in research.json |
| `size_score`, `ip_score` | research.json **or typed straight into the sheet** | hand-researched |
| `request_score`, `player_requests` | `player-requests*.txt` | |
| `code_notes`, `code_notes_score` | stage 2.5 | count, scored 10 up to 20 notes sliding down to 0; **50+ is an outright exclusion** |
| `demoted_achievements` | stage 2 | non-zero means an abandoned set exists |
| `want_to_play`, `my_notes` | **you** | free-form, never overwritten |
| `auto_notes` | computed | why a score came out the way it did |

### Editing the table by hand

The CSV is the living document, not a throwaway report. Type into it freely:

* `want_to_play` and `my_notes` are yours and are never touched.
* `size_score` and `ip_score` can be typed in directly instead of going through
  research.json. A rebuild keeps whatever the sheet had, and research.json wins only where
  it actually has a value for that game.
* `genre_score` is the exception - it is computed, so edit it per game in research.json.
  Carrying it over would mean a change to the genre rules never took effect.

After editing any score, recompute `overall`:

```
node next-game/update-scores.js ps1
node next-game/update-scores.js ps1 --dry-run   # report the changes, write nothing
```

That reads the CSV and writes the CSV - nothing else - so it is safe to run at any time.
`build-table.js` also recomputes `overall`, but it rebuilds every derived column from the
pipeline; use it when an earlier stage has produced new data.

### research.json

`size_score` and `ip_score` cannot come from any API, so they are hand-researched in
`next-game/research.json`, keyed by game ID:

```json
{"1234": {"genre": "Action-Adventure", "genre_score": 8, "size": 8, "ip": 10, "note": "why"}}
```

`genre` overrides RA's, `genre_score` overrides the rules outright for a game where a rule
is right in general but wrong here. Re-run stage 3 after editing - it is instant and local.

To pick what to research next, filter the table on `excluded_as` empty and
`needs_research` = yes, sorted by `overall`.

### Japan-only guess

`japan_only` / `japan_source` guess whether a title never left Japan. RA stores every title
in Latin script even for Japan-only games, so there is no character set to detect - instead
`JAPAN_TITLE_MARKERS` in build-table.js looks for romanized Japanese grammar (particles like
`wo`/`ga`, story-title words like `densetsu`/`monogatari`/`gaiden`) that essentially never
survives Western localization. Tuned for precision, not recall: it catches ~90 titles with
no observed false positive, but misses plenty of Japan-only games with plain-sounding
titles - those get `japan_source: research` instead once actually looked into and confirmed
with a `"japan": true` field in research.json. An empty `japan_only` means no strong signal
either way, not a confirmed international release.

### Genre filter

Two things disqualify a game, both recorded in `excluded_as`, and either forces `overall`
to 0 so the row sinks to the bottom of the table rather than leaving it.

**50 or more code notes** is a hard no - too much of the memory is already mapped to be
worth taking on as a junior dev. A low score could not express that: a 0 on one component
of a weighted mean still leaves a row sitting mid-table.

**Genre.** `EXCLUDED_GENRES` marks whole families rather than scoring them low:
racing, puzzle, visual novel, horror and 2D platformer from requirements.md, plus sports,
pinball/rhythm/board/card, educational/compilation/minigames, life & management sim,
fighting, and tactical/turn-based RPG. Excluded rows **stay in the table** with
`excluded_as` naming the family, so a wrong call is one filter away from being undone.

Only games with a known genre can be filtered, so this bites on 39% of the list.

## What the API cannot answer

| requirements.md | Where it comes from |
| --- | --- |
| Console, type, no achievements, not claimed | stage 1 |
| No Japanese game | stage 1, as a `japanOnly` hint from the region tag |
| Genre | stage 2 - RA's Genre field is free text and often empty |
| **Player requests** | **not in the API at all** - check the game page by hand |
| **Code notes** | **not in the Web API** - see below |

Player request counts exist only per user (`API_GetUserSetRequests.php`), in both V1 and the
unannounced V2 API. The game page shows the number, but Cloudflare blocks scripted fetches.

Code notes are only on the connect API, the one `@cruncheevos/cli` uses:
`POST dorequest.php` with `r=codenotes2&g=<gameId>`, authenticated with the `Username` and
`Token` from `RAPrefs*.cfg` in the `RACACHE` directory - not the web API key.

## API V2

Live at `https://api.retroachievements.org/v2`, JSON:API, authenticated with the *same* web
API key but as an `X-API-Key` header. Rate limited to 60 requests/minute. Unannounced, so
treat it as unstable - these scripts use V1.

Worth knowing for later: V2 has no `genre` field at all, but it does expose
`achievementsUnpublished`, `playersTotal`, `timesBeaten` and `medianTimeToBeatSeconds` on
`/v2/games` (that last one is a real signal for "big/complex enough"), and it can classify
games by genre through the hub system - `/v2/hubs` then `/v2/hubs/{id}/games`, where RA
keeps its `[Genre - ...]` collections. That is far cheaper than stage 2's per-game requests.

## What is in data/

| | |
| --- | --- |
| **Inputs**, hand-edited | `../research.json`, `../player-requests*.txt` |
| **Caches**, cost API requests - do not delete | `gamelist-*.json`, `claims.json`, `consoles.json`, `details/`, `code-notes/` |
| **Pipeline**, regenerable for free | `candidates-*.json`, `shortlist-*.json`, `code-note-counts.json` |
| **The table** | `games-<console>.csv` |

Everything except the caches can be rebuilt without spending a single request.

## Links

* RA API docs: https://api-docs.retroachievements.org/llms.txt
* V2 source: https://github.com/RetroAchievements/RAWeb/tree/master/app/Api/V2
