#!/usr/bin/env node
/*
 * Merges a batch of research entries into next-game/research.json without clobbering
 * what is already there. Reads a JSON object of {gameId: {genre, size, ip, note, ...}}
 * from stdin and shallow-merges each entry into the existing one for that id.
 *
 * Used while researching many games in a row: each batch is merged and saved immediately,
 * so the file is never in a half-written state and a stopped run loses nothing.
 *
 * Usage: echo '{"1234": {"size": 8, "ip": 10}}' | node next-game/merge-research.js
 */

import {readFileSync, writeFileSync} from 'node:fs';

const FILE = 'next-game/research.json';

const input = JSON.parse(readFileSync(0, 'utf8'));
const existing = JSON.parse(readFileSync(FILE, 'utf8'));

let added = 0;
let updated = 0;

for (const [id, entry] of Object.entries(input)) {
  if (existing[id]) updated += 1;
  else added += 1;
  existing[id] = {...existing[id], ...entry};
}

writeFileSync(FILE, `${JSON.stringify(existing, null, 2)}\n`);
console.log(`research.json: ${added} added, ${updated} updated, ${Object.keys(existing).length - 1} total entries.`);
