/*
 * The consoles worth considering under requirements.md: 32-bit-ish, retail library,
 * not a PS2/GameCube-sized project. Shared by fetch-game-lists.js and enrich-candidates.js
 * so both accept the same short names.
 *
 * Aliased but deliberately left out of DEFAULT_CONSOLES: dsi is mostly DSiWare and too
 * simple, 3do and jaguar have thin libraries. Anything not listed at all can still be
 * passed by its full RA name or its numeric console ID - names are resolved against
 * API_GetConsoleIDs.php.
 */

export const DEFAULT_CONSOLES = ['gba', 'ds', 'ps1', 'n64', 'dreamcast', 'saturn'];

export const CONSOLE_ALIASES = {
  gba: 'Game Boy Advance',
  ds: 'Nintendo DS',
  dsi: 'Nintendo DSi',
  ps1: 'PlayStation',
  psx: 'PlayStation',
  n64: 'Nintendo 64',
  saturn: 'Sega Saturn',
  dreamcast: 'Dreamcast',
  '3do': '3DO Interactive Multiplayer',
  jaguar: 'Atari Jaguar',
};
