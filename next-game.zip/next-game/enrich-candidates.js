#!/usr/bin/env node
/*
 * Stage 2 of picking the next game: takes a candidate list from fetch-game-lists.js and
 * spends one API_GetGameExtended.php request per game to pull the data GetGameList does
 * not carry - Genre, Developer, Publisher, Released - then scores each game against the
 * Genre rules in requirements.md.
 *
 * This is the expensive stage: one request per game at ~1/s, so a PlayStation run is well
 * over half an hour. It prints the plan and then fetches; --dry-run stops after the plan.
 * Every game's response is cached under data/details/, so Ctrl+C is safe - the next run
 * picks up where this one stopped, and re-scoring an existing cache costs nothing.
 *
 * GetGameExtended is called with f=5, which reports unofficial/demoted achievements. Our
 * candidates have no published achievements by construction, so a non-zero count there
 * means somebody already started and abandoned a set - worth knowing before claiming.
 *
 * Still not covered, because no Web API endpoint exposes it (V1 or V2):
 *   Player requests - only per-user (API_GetUserSetRequests.php), never per-game
 *   Code notes      - connect API only: dorequest.php r=codenotes2
 * Both stay manual checks on the game page for whatever survives this stage.
 *
 * Usage: node next-game/enrich-candidates.js ps1              - the whole candidate list
 *        node next-game/enrich-candidates.js ps1 --dry-run    - just print what it would cost
 *        node next-game/enrich-candidates.js ps1 --limit 300  - stop after that many games
 *        node next-game/enrich-candidates.js ps1 --include-japan
 *        node next-game/enrich-candidates.js ps1 --region USA - only that region
 *
 * Writes shortlist-<console>.json, which build-table.js turns into the games table.
 */

import {mkdirSync, readdirSync} from 'node:fs';
import {join} from 'node:path';
import {CONSOLE_ALIASES} from './consoles.js';
import {RATE_LIMIT_MS, cached, get, readJson, slugify, writeJson} from './ra-api.js';

const DEFAULT_OUT = 'next-game/data';

/*
 * requirements.md, Genre section. RA's Genre field is free text and frequently empty, so
 * this is a triage aid and not a verdict: `drop` is an outright rule from requirements.md,
 * `flag` is something to look at before committing. Matched case-insensitively as a
 * substring of the whole genre string, since RA writes things like "Action, Platformer".
 */
const GENRE_RULES = [
  {match: 'platform', verdict: 'drop', reason: 'platformer - already did Rugrats and Turok', unless: '3d'},
  {match: 'racing', verdict: 'drop', reason: 'racing'},
  {match: 'driving', verdict: 'drop', reason: 'racing'},
  {match: 'puzzle', verdict: 'drop', reason: 'puzzle game'},
  {match: 'visual novel', verdict: 'drop', reason: 'visual novel'},
  {match: 'dungeon crawler', verdict: 'flag', reason: 'close to Monster Force'},
  {match: 'rpg', verdict: 'flag', reason: 'RPG - check it is not a huge one'},
  {match: 'role-playing', verdict: 'flag', reason: 'RPG - check it is not a huge one'},
];

const applyGenreRules = (genre) => {
  const text = (genre ?? '').toLowerCase();
  if (!text) return {verdict: 'unknown', reasons: ['no genre recorded on RA']};

  const hits = GENRE_RULES.filter((rule) => text.includes(rule.match) && !(rule.unless && text.includes(rule.unless)));
  const dropped = hits.filter((rule) => rule.verdict === 'drop');

  if (dropped.length > 0) return {verdict: 'drop', reasons: dropped.map((rule) => rule.reason)};
  if (hits.length > 0) return {verdict: 'flag', reasons: hits.map((rule) => rule.reason)};
  return {verdict: 'keep', reasons: []};
};

/* One request per game, cached by game ID so re-runs and resumes are free. */
const fetchDetails = (id, dir, options) => cached(
  join(dir, `${id}.json`),
  () => get('API_GetGameExtended.php', {i: id, f: 5}, {expect: 'object'}),
  {...options, quiet: true},
);

const enrich = (candidate, details) => {
  const genre = details.Genre || '';
  const {verdict, reasons} = applyGenreRules(genre);

  return {
    ...candidate,
    genre,
    developer: details.Developer || '',
    publisher: details.Publisher || '',
    released: details.Released || '',
    unofficialAchievements: Number(details.NumAchievements) || 0,
    verdict,
    reasons,
  };
};

/*
 * Narrows the candidate list before anything is fetched. requirements.md rules out Japanese
 * games, and a Japan-only release is the closest proxy the game list carries, so those go
 * first. Everything here is optional - by default the whole list gets enriched.
 */
const narrow = (candidates, {includeJapan, region, limit}) => {
  let shortlist = candidates;

  if (!includeJapan) shortlist = shortlist.filter((game) => !game.japanOnly);
  if (region) shortlist = shortlist.filter((game) => game.regions.includes(region));

  return limit ? shortlist.slice(0, limit) : shortlist;
};

const parseArgs = (argv) => {
  const options = {out: DEFAULT_OUT, limit: null, includeJapan: false, region: null, dryRun: false, refresh: false};
  const consoles = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--dry-run') options.dryRun = true;
    else if (arg === '--refresh') options.refresh = true;
    else if (arg === '--include-japan') options.includeJapan = true;
    else if (arg === '--limit') options.limit = Number(argv[++i]);
    else if (arg === '--region') options.region = argv[++i];
    else if (arg === '--out') options.out = argv[++i];
    else if (arg.startsWith('--')) throw new Error(`Unknown option: ${arg}`);
    else consoles.push(arg);
  }

  if (consoles.length !== 1) {
    throw new Error('Name exactly one console, e.g. `node next-game/enrich-candidates.js ps1`');
  }
  if (options.limit !== null && (!Number.isInteger(options.limit) || options.limit < 1)) {
    throw new Error(`--limit needs a positive whole number, got ${options.limit}`);
  }

  options.console = consoles[0];
  return options;
};

/* Candidate files are named after the RA console name, which is not the alias we were given. */
const findCandidateFile = (input, dir) => {
  const wanted = slugify(CONSOLE_ALIASES[input.toLowerCase()] ?? input);
  const files = readdirSync(dir).filter((file) => file.startsWith('candidates-') && file.endsWith('.json'));
  const slugs = files.map((file) => file.slice('candidates-'.length, -'.json'.length));

  const match = slugs.find((slug) => slug === wanted)
    ?? slugs.find((slug) => slug.includes(wanted) || wanted.includes(slug));

  if (!match) {
    throw new Error(`No candidate list for "${input}" in ${dir}. Have: ${slugs.join(', ') || 'none'}\n`
      + 'Run fetch-game-lists.js first.');
  }
  return {slug: match, file: join(dir, `candidates-${match}.json`)};
};

const main = async () => {
  const options = parseArgs(process.argv.slice(2));
  const {slug, file} = findCandidateFile(options.console, options.out);

  const candidates = readJson(file);
  const shortlist = narrow(candidates, options);
  const name = candidates[0]?.consoleName ?? slug;

  console.log(`${name}: ${candidates.length} candidates, ${shortlist.length} after narrowing.`);

  const detailsDir = join(options.out, 'details');
  mkdirSync(detailsDir, {recursive: true});
  const alreadyCached = new Set(readdirSync(detailsDir).map((entry) => entry.replace('.json', '')));
  const toFetch = options.refresh ? shortlist : shortlist.filter((game) => !alreadyCached.has(String(game.id)));

  const seconds = Math.ceil((toFetch.length * RATE_LIMIT_MS) / 1000);
  const estimate = seconds > 90 ? `about ${Math.ceil(seconds / 60)} min` : `about ${seconds}s`;
  console.log(`${toFetch.length} still to fetch, ${estimate} at ${RATE_LIMIT_MS}ms apart.`);

  if (options.dryRun) {
    console.log('Dry run, stopping here. Drop --dry-run to fetch, or narrow with --limit / --region.');
    return;
  }
  if (toFetch.length > 0) console.log('Ctrl+C is safe - every response is cached as it arrives.\n');

  const enriched = [];
  for (const [index, candidate] of shortlist.entries()) {
    const details = await fetchDetails(candidate.id, detailsDir, options);
    enriched.push(enrich(candidate, details));

    const position = String(index + 1).padStart(String(shortlist.length).length);
    console.log(`  [${position}/${shortlist.length}] ${candidate.title} - ${details.Genre || 'no genre'}`);
  }

  const out = join(options.out, `shortlist-${slug}.json`);
  writeJson(out, enriched);

  const counts = enriched.reduce((tally, game) => ({...tally, [game.verdict]: (tally[game.verdict] ?? 0) + 1}), {});
  console.log(`\n${JSON.stringify(counts)}`);
  console.log(`Wrote ${out} - next: build-table.js`);
};

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
