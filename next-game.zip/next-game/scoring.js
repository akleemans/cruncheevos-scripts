/*
 * How the columns of the games table combine into `overall`.
 *
 * Kept apart from build-table.js so update-scores.js can recompute `overall` straight from
 * the CSV - including any score you edited by hand in the spreadsheet - without rebuilding
 * the table from the pipeline.
 */

/* Weights need not add up to 1: whichever scores a row actually has get renormalised. */
export const WEIGHTS = {
  genre_score: 0.25,
  size_score: 0.35,
  request_score: 0.15,
  code_notes_score: 0.15,
  ip_score: 0.1,
};

/* Filled in by hand in the spreadsheet, so a rebuild must read them back, never overwrite. */
export const MANUAL_COLUMNS = ['want_to_play', 'my_notes'];

/*
 * Scores with no source but a person. research.json is where I record what I look up, but
 * these can equally be typed straight into the spreadsheet, so a rebuild carries over
 * whatever the old table had - research.json wins when it has a value for that game.
 *
 * genre_score is deliberately NOT here: it is computed from the genre rules, and carrying
 * it over would mean a change to GENRE_SCORES never took effect. Override it per game in
 * research.json instead.
 */
export const CARRIED_SCORES = ['size_score', 'ip_score'];

const asNumber = (value) => {
  if (typeof value === 'number') return value;
  if (typeof value !== 'string' || value.trim() === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

/*
 * A disqualified row scores 0 rather than being dropped, so it still sorts to the bottom of
 * the one table instead of disappearing into a second file. Everything else is a weighted
 * mean over the scores that are known, so an unresearched row still gets a usable number.
 */
export const overallScore = (row) => {
  if (row.excluded_as) return 0;

  const present = Object.keys(WEIGHTS)
    .map((column) => [column, asNumber(row[column])])
    .filter(([, value]) => value !== null);

  if (present.length === 0) return null;

  const weight = present.reduce((sum, [column]) => sum + WEIGHTS[column], 0);
  const total = present.reduce((sum, [column, value]) => sum + (value * WEIGHTS[column]), 0);
  return Math.round((total / weight) * 10) / 10;
};

/* Sorts the table the way it is meant to be read: best first, disqualified last. */
export const byOverall = (a, b) => (asNumber(b.overall) ?? -1) - (asNumber(a.overall) ?? -1)
  || String(a.title).localeCompare(String(b.title));
